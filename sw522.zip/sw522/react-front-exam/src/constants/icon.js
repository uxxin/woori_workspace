export const TODO_CATEGORY_ICON = {
    TODO: '📑',
    PROGRESS: '👀',
    DONE: '😀',
}